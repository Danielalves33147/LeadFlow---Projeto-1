package br.com.leadflow.dto;

import br.com.leadflow.model.enums.UserRole;
import br.com.leadflow.model.enums.UserStatus;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.util.List;

public final class AuthDTOs {

    private AuthDTOs() {}public record LoginRequest(
        @NotBlank @Email String email,
        @NotBlank @Size(min = 8, max = 72) String password
    ) {}public record RegisterRequest(
        @NotBlank @Size(min = 2, max = 120) String name,
        @NotBlank @Email @Size(max = 180) String email,
        @NotBlank @Size(min = 2, max = 160) String companyName,
        @NotBlank @Size(min = 14, max = 18) String cnpj,
        @NotBlank @Size(min = 8, max = 72) String password,
        @AssertTrue boolean acceptedTerms,
        @AssertTrue boolean acceptedPrivacy
    ) {}public record RefreshRequest(@NotBlank String refreshToken) {}public record LogoutRequest(@NotBlank String refreshToken) {}public record AuthUser(
        Long id,
        String name,
        String email,
        UserRole role,
        UserStatus status,
        Long companyId,
        String companyName,
        Long primaryBranchId,
        String primaryBranchName,
        List<Long> authorizedBranchIds
    ) {}public record AuthResponse(
        String accessToken,
        String refreshToken,
        long expiresIn,
        AuthUser user
    ) {}
}
